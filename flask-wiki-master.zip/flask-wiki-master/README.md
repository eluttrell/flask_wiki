# Wiki site

A wiki website built in Flask. Includes CamelCase linking, ability to write/edit/delete page entries, and a home page to see all created pages.
